# Treino de Funções

## Passos

1- Criar uma Função que soma as notas dos 4 bimestres do aluno
2- Passar as notas de cada bimestre por parametro(objeto)
3- Retornar o total de notas do aluno
